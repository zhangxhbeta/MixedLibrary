package mixedserver.demo.tools;

/**
 * 本项目的工具类
 * 
 * @author zhangxiaohui
 * 
 */
public class GlobalTools {

	// RPC服务器接口地址
	public static final String SERVER_URL = "http://192.168.0.142:8080/JSON-RPC?debug=true";
}
